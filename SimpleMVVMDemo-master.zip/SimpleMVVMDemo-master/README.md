# SimpleMVVMDemo
利用CoreData特性简化MVVM项目架构代码示例 文章见我的博客[《利用CoreData特性简化MVVM项目架构》](https://skyshen.cn/liyongcoredatatexingjianhuamvvmxiangmujiagou/)
